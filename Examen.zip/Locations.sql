CREATE TABLE Locations (
    LocationID INT PRIMARY KEY AUTO_INCREMENT,
    Country VARCHAR
    City VARCHAR
    Latitude DECIMAL -- Coordenadas geográficas
    Longitude DECIMAL
    